<?php
	session_start();
	include("library/conn.php");

	$role_rs = array();
	$get_role_mode = mysqli_query($conn, "SELECT * FROM user_role_privileges WHERE userID = '". $_SESSION['userIdd'] ."' AND roleName = 'account_numbers'") or die (mysqli_error($conn));
	if (mysqli_num_rows($get_role_mode) > 0) {
		$role_rs = mysqli_fetch_array($get_role_mode);
	} else {
		$role_rs = ['-1', '-1', '-1', '-1', '-1', '-1'];
	}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Account Numbers => <?php echo $sys_comp_name; ?></title>
		<?php include("library/head.php");?>
	</head>
	<body class="app sidebar-mini">

		<!-- Navbar-->
		<?php include("library/header.php");?>
		<!-- Sidebar menu-->
		<?php include("library/sidebar.php");?>
		<main class="app-content">
			<div class="app-title">
				<div>
					<h4><i class="fa fa-hashtag fa-lg"></i> ACCOUNT NUMBERS</h4>
					<p>Account Numbers List Page</p>
				</div>
				<ul class="app-breadcrumb breadcrumb">
					<li class="breadcrumb-item"><i class="fa fa-home"></i></li>
					<li class="breadcrumb-item"><a href="account-numbers">Account Numbers</a></li>
				</ul>
			</div>
      
			<!-- Zones modal -->
			<!-- Button trigger modal -->
			<div class="row" style="padding-bottom: 10px;">
				<div class="col-md-12">
				    <?php
                        if ($_SESSION['userType'] == 0) {
                            ?><button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#addNewAccountNumberModal"><i class="fa fa-plus"></i> New Account</button><?php
                        } else {
                            if ($role_rs[3] == '1') {
                                ?><button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#addNewAccountNumberModal"><i class="fa fa-plus"></i> New Account</button><?php
                            }
                        }
                    ?>
				</div>
			</div>

			<?php include("models/admin_config.php");?>
			<?php include("models/system_config.php");?>

			<!-- Investment Types page -->
			<div class="row">
				<div class="col-md-12">
					<div class="tile">
						<div class="tile-body">
							<div class="table-responsive">
								<table class="table table-striped table-bordered table-sm" id="accountNumbersTable">
									<thead>
										<tr align="center">
											<th>Logo</th>
											<th>Name</th>
											<th>Account Information</th>
											<th>Account Type</th>
											<th>Created By</th>
											<th>Create Date</th>
                                            <?php if ($role_rs[4] == '0' && $role_rs[5] == '0') { } else {?><th><center>Action</center></th><?php } ?>
										</tr>
									</thead>
									<tbody>
										<?php
											$getAccountNumbers = mysqli_query($conn, "SELECT account_numbers.accountNoID, payment_gateways.gatewayLogo, payment_gateways.gatewayName, account_numbers.accountNoName, account_numbers.accountNumber, payment_gateways.gatewayType, users.userName, account_numbers.registerDate FROM account_numbers JOIN payment_gateways ON (account_numbers.gatewayID = payment_gateways.gatewayID) JOIN users ON (account_numbers.registeredBy = users.userID) ORDER BY account_numbers.accountNoName ASC") or die(mysqli_error($conn));
											$account_type_list = array("Bank Account", "Mobile Account", "Cash Account");
											while ($rs = mysqli_fetch_array($getAccountNumbers)) {
												?>
													<tr>
														<td class="py-1" align="center"><img class="img-fluid img-thumbnail rounded" src="<?php echo $rs[1]; ?>" width="35px" height="35px"/></td>
														<td align="left"><?php echo $rs[2]; ?></td>
														<td align="left"><?php echo $rs[3]. " (". $rs[4]. ")"; ?></td>
														<td align="center"><?php echo $account_type_list[$rs[5] - 1]; ?></td>
														<td align="left"><?php echo $rs[6]; ?></td>
														<td align="center"><?php echo substr($rs[7], 0, 10); ?></td>
														<?php
                                                            if ($_SESSION['userType'] == 0) {
                                                                ?><td align="center">
        															<span class="btn btn-danger btn-sm btnDeleteAccountNumber" id="<?php echo "Delete". $rs[0]; ?>" data-id="<?php echo $rs[0]; ?>"><i class="fa fa-fw fa-lg fa-trash"></i> Delete</span> 
        														</td><?php
                                                            } else {
                                                                if ($role_rs[5] == '1') {
                                                                    ?><td align="center">
            															<span class="btn btn-danger btn-sm btnDeleteAccountNumber" id="<?php echo "Delete". $rs[0]; ?>" data-id="<?php echo $rs[0]; ?>"><i class="fa fa-fw fa-lg fa-trash"></i> Delete</span> 
                                                                    </td><?php
                                                                }
                                                            }
                                                        ?>
													</tr>
												<?php
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		
		<!-- Essential javascripts for application to work-->
		<?php include("library/footer.php");?>	
		<?php include("library/scripts.php");?>
		<script type="text/javascript">$('#bankAccountsAndNumbersTable').DataTable({"pageLength": 100});</script>
		<script type="text/javascript"> $("#cmbAccountNumbersAccountType").select2({ tags: false, dropdownParent: $("#addNewAccountNumberModal") });</script>
		<script type="text/javascript"> $("#cmbAccountNumbersGatewayName").select2({ tags: false, dropdownParent: $("#addNewAccountNumberModal") });</script>

		

	</body>
</html>