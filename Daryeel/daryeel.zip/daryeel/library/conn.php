<?php 
$sys_comp_name = "Somali Teachers Syndicate";
$conn = mysqli_connect("localhost", "root", "","daryeel_sys_db");
if ($conn) {

} else {
	echo "<script>alert('Database connection failed...)</script>";
}
